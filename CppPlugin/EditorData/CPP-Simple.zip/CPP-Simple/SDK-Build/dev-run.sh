./CPP-Simple -w -s -p "Resources;BaseResources" -pp ".;..;"
