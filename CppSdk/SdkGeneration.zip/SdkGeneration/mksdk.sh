#!/bin/bash
# unofficial linux Atomic C++ SDK
# --Added pak/BaseResources.pak to eliminate reliance on existing Atomic Build resources
# --deploy back into the Atomic Build! and no longer copy the cpp feature examples
# --redo script, command line arguments are now :
#    Atomic Game Engine path with -a value or --atomic-path value or -a=value or --atomic-path=value (manditory)
#    SDK path with -s value or --sdk-path value or -s=value or --sdk-path=value 
#    Doxygen file to build documentation with -d value or --doxygen-file value or -d=value or --doxygen-file=value
#    Zip up the SDK when assembly is completed, with either -z or --zip
#    Move SDK into Atomic Game Engine when assembly is completed, with either -m or --move
#    Include C++ examples, with either -e or --examples
#
# JimMarlowe
#


# Initialize our own variables:
SDKFILE=""
DOXYFILE=""
ATOMICFILE=""
MOVER=0
ZIP=0
EXAMPLES=0
HELP=0

# As long as there is at least one more argument, keep looping
while [[ $# -gt 0 ]]; do
    key="$1"
    case "$key" in

        # Also a flag type option. Will catch either -h or --help
        -h|--help)
        HELP=1
        ;;
        # Also a flag type option. Will catch either -m or --move
        -m|--move)
        MOVER=1
        ;;
        # Also a flag type option. Will catch either -z or --zip
        -z|--zip)
        ZIP=1
        ;;
        # Also a flag type option. Will catch either -e or --examples
        -e|--examples)
        EXAMPLES=1
        ;;

        # This is an arg value type option. Will catch -s value or --sdk-path value
        -s|--sdk-path)
        shift # past the key and to the value
        SDKFILE="$1"
        ;;
        # This is an arg=value type option. Will catch -s=value or --sdk-path=value
        -s=*|--sdk-path=*)
        # No need to shift here since the value is part of the same string
        SDKFILE="${key#*=}"
        ;;

        # This is an arg value type option. Will catch -a value or --atomic-path value
        -a|--atomic-path)
        shift # past the key and to the value
        ATOMICFILE="$1"
        ;;
        # This is an arg=value type option. Will catch -a=value or --atomic-path=value
        -a=*|--atomic-path=*)
        # No need to shift here since the value is part of the same string
        ATOMICFILE="${key#*=}"
        ;;

        # This is an arg value type option. Will catch -d value or --doxygen-file value
        -d|--doxygen-file)
        shift # past the key and to the value
        DOXYFILE="$1"
        ;;
        # This is an arg=value type option. Will catch -d=value or --doxygen-file=value
        -d=*|--doxygen-file=*)
        # No need to shift here since the value is part of the same string
        DOXYFILE="${key#*=}"
        ;;

        *)
        # Do whatever you want with extra options
        echo "Unknown option '$key'"
        ;;
    esac
    # Shift after checking all the cases to get the next option
    shift
done

#echo "HELP=$HELP, EXAMPLES=$EXAMPLES, MOVER=$MOVER, ZIP=$ZIP, SDKFILE='$SDKFILE', ATOMICFILE='$ATOMICFILE', DOXYFILE='$DOXYFILE' "

if [[ $HELP = 1 ]]; then
echo "mksdk help:"
echo "set the Atomic Game Engine path with -a value or --atomic-path value or -a=value or --atomic-path=value"
echo "set the SDK path with -s value or --sdk-path value or -s=value or --sdk-path=value"
echo "set the Doxygen file to build documentation with -d value or --doxygen-file value or -d=value or --doxygen-file=value"
echo "Zip up the SDK when assembly is completed, with either -z or --zip"
echo "Move SDK into Atomic Game Engine when assembly is completed, with either -m or --move"
echo "Include C++ examples in the SDK, with either -e or --examples"
exit 1
fi

if [[  $ATOMICFILE = "" ]]; then
echo "mksdk error"
echo "Please enter the directory for the Atomic Game Engine"
echo " "
echo "Atomic Game Engine path with -a value or --atomic-path value or -a=value or --atomic-path=value"
echo "SDK path with -s value or --sdk-path value or -s=value or --sdk-path=value"
echo "Doxygen file to build documentation with -d value or --doxygen-file value or -d=value or --doxygen-file=value"
echo "Zip up the SDK when assembly is completed, with either -z or --zip"
echo "Move SDK into Atomic Game Engine when assembly is completed, with either -m or --move"
echo "Include C++ examples, with either -e or --examples"
exit 1
fi

if [[  $SDKFILE = "" ]]; then
echo "no directory given for SDK, defaulting to /tmp/SDK"
SDKFILE='/tmp/SDK'
fi


# making a new SDK, clear if it exists
rm -rf $SDKFILE ;
mkdir $SDKFILE ;

#make lib dir
mkdir $SDKFILE/lib ;

#fill in includes
rsync -a --prune-empty-dirs --include '*/' --include '*.h' --exclude '*' $ATOMICFILE/Source/ $SDKFILE/include ; 

#copy in some non-header files
cp $ATOMICFILE/Source/ThirdParty/kNet/include/kNet/*.inl $SDKFILE/include/ThirdParty/kNet/include/kNet

#copy in libs
find $ATOMICFILE/Artifacts/Build/Linux -name '*.a' -exec cp -pr '{}' $SDKFILE'/lib/' ';' ;

#copy in cpp examples
if [[ $EXAMPLES = 1 ]]; then
cp -rp $ATOMICFILE/Submodules/AtomicExamples/FeatureExamples/CPlusPlus $SDKFILE/examples
fi

#
# the dance to make BaseResources.pak
#
#we have to build PackageTool, so go there
cd $ATOMICFILE/Artifacts/Build/Linux/Source/Tools/PackageTool
#and make it
make
# now we better have $ATOMICFILE/Artifacts/Build/Linux/Source/Tools/PackageTool/PackageTool
# create a staging area in the SDK
mkdir $SDKFILE/pak
mkdir $SDKFILE/pak/BaseResources
# and copy in PackageTool so users can package their own resoources
cp $ATOMICFILE/Artifacts/Build/Linux/Source/Tools/PackageTool/PackageTool $SDKFILE/pak
# copy in the CoreData resources needed to create the pak file
cp -rp $ATOMICFILE/Artifacts/AtomicEditor/Resources/CoreData $SDKFILE/pak/BaseResources
# copy in the PlayerData resources needed to create the pak file
cp -rp $ATOMICFILE/Artifacts/AtomicEditor/Resources/PlayerData $SDKFILE/pak/BaseResources
# move some stuff around so we only need to make one (combo) file
mv $SDKFILE/pak/BaseResources/PlayerData/DefaultUI $SDKFILE/pak/BaseResources/CoreData
# get rid of some fluff
rm -rf $SDKFILE/pak/BaseResources/PlayerData
# prep for packaging
cd $SDKFILE/pak/BaseResources
# make the pak file
$ATOMICFILE/Artifacts/Build/Linux/Source/Tools/PackageTool/PackageTool CoreData BaseResources.pak -c
# move it up
mv BaseResources.pak ..
cd ..
# get rid of more fluff
rm -fr BaseResources

#add docs ?
if [ $DOXYFILE ]; then
echo 'Generating docs'
cat $DOXYFILE > $SDKFILE/Doxyfile.age.tmp
echo "OUTPUT_DIRECTORY       = $SDKFILE" >> $SDKFILE/Doxyfile.age.tmp
cd $ATOMICFILE/Source
doxygen $SDKFILE/Doxyfile.age.tmp
fi

if [[ $ZIP = 1 ]]; then
echo 'Zipping SDK'
cd $SDKFILE
cd ..
zip -r $SDKFILE.zip $SDKFILE 
ls -ltr $SDKFILE.zip
fi

if [[ $MOVER = 1 ]]; then
echo 'Deploying SDK'
rm -rf $ATOMICFILE/Artifacts/AtomicEditor/Resources/ToolData/Deployment/SDK
mv $SDKFILE $ATOMICFILE/Artifacts/AtomicEditor/Resources/ToolData/Deployment/SDK
fi

echo 'the SDK is completed'
