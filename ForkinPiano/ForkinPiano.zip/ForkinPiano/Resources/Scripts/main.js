// Copyright (c) 2017 Piranasoft
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
// Forkin Piano app
// JimMarlowe, Piranasoft

// couldnt we do multi-touch on android? and play chopsticks?  lol - yes.

//Load scene that is the forkinpiano keyboard
Atomic.player.loadScene("Scenes/Scene.scene");
var gain_ = 0.2;
var mycamera = Atomic.player.currentScene.getComponent("Camera", true);
var myoctree = Atomic.player.currentScene.getComponent("Octree", true);
var mysound = "Sounds/scream.wav";  // default forkin sound
var pfx = 3.2;  // how fast the pirana goes

// stick a forkin fork in it.
var iFish = Atomic.player.currentScene.getChild("piranax0"); // and feed the fish.

// load up the extravagant UI
var view = new Atomic.UIView();
var mylayout = new Atomic.UILayout();
mylayout.rect = view.rect;
mylayout.layoutSize = Atomic.UI_LAYOUT_SIZE_AVAILABLE;
mylayout.layoutDistribution = Atomic.UI_LAYOUT_DISTRIBUTION_AVAILABLE;
view.addChild(mylayout);
if (( Atomic.platform == "Android" ) || Atomic.platform == "iOS") {
	mylayout.load("Scenes/forkin-mhud.ui.txt"); // load the mobile layout
    Atomic.ui.loadSkin("Sprites/mobile.tb.txt");
    Atomic.ui.setDefaultFont("Vera", 14);
}
else {
	mylayout.load("Scenes/forkin-dhud.ui.txt"); // load the desktop layout
    Atomic.ui.loadSkin("Sprites/desktop.tb.txt");
}

// button work
var button1 = mylayout.getWidget("Exit");
button1.onClick = function () {
	Atomic.engine.exit();
};

var button2 = mylayout.getWidget("Quiet");
button2.onClick = function () {
  gain_ = 0.04;
};

var button3 = mylayout.getWidget("Soft");
button3.onClick = function () {
  gain_ = 0.1;
};

var button4 = mylayout.getWidget("Medium");
button4.onClick = function () {
  gain_ = 0.22;
};

var button5 = mylayout.getWidget("Loud");
button5.onClick = function () {
  gain_ = 0.3;
};

var button6 = mylayout.getWidget("Eleven");
button6.onClick = function () {
  gain_ = 1.0;
};

var button10 = mylayout.getWidget("Pirana");
button10.onClick = function () {
  mysound = "Sounds/scream.wav";
};

var button11 = mylayout.getWidget("Cat");
button11.onClick = function () {
   mysound = "Sounds/mewo1.wav";
};

var button12 = mylayout.getWidget("Chicken");
button12.onClick = function () {
   mysound = "Sounds/chicken44k.wav";
};

var button13 = mylayout.getWidget("Cow");
button13.onClick = function () {
   mysound = "Sounds/moo-notification.wav";
};

var button14 = mylayout.getWidget("Dog");
button14.onClick = function () {
    mysound = "Sounds/dog44k.wav";
};

var button15 = mylayout.getWidget("Piano");
button15.onClick = function () {
	mysound = "Sounds/toypiano.wav";
};

var mull = 59.0;   //55.0;  // this isnt even close, lol.

// plays a note from a specific key on the forkinpiano
var playme = function(soundFile, adder)
{
    var sfx = Atomic.cache.getResource("Sound", soundFile);
    sfx.looped = false;
    var sfxNode = Atomic.player.currentScene.createChild("SFXNode");
    var sfxSource = sfxNode.createComponent("SoundSource");
    sfxSource.setAutoRemoveMode(true);
    sfxSource.gain = gain_;
    sfxSource.soundType = Atomic.SOUND_AMBIENT;
    sfxSource.frequency = 44100 + (adder * mull);
    sfxSource.play(sfx);
};


// we just want to be heard...
var pressme = function ( xpos, ypos )
{
    xpos /= Atomic.graphics.width;  //where in the world did we press/touch
    ypos /= Atomic.graphics.height;

    var ray = mycamera.getScreenRay(xpos, ypos);  /// calculate the screen ray at the press/touch point
	
    var result = myoctree.rayCastSingle(ray, Atomic.RAY_TRIANGLE, Atomic.M_INFINITY, Atomic.DRAWABLE_GEOMETRY);
   	if (result)  // did we hit something? tell me, I wasnt looking...
    {		
		var dosomething = false;  // its different with mobile touch vs desktop mouse 

     	if (Atomic.platform == "Android"|| Atomic.platform == "iOS") dosomething = true;
       	else dosomething = Atomic.input.getMouseButtonPress(Atomic.MOUSEB_LEFT);
		
		if ( dosomething )
        {
            if (result.node.getName()=="keyCUpper" ) playme ( mysound, 0 );	// AND DO THE REAL JOB...
            else if (result.node.getName()=="KeyCLower" ) playme ( mysound, 0 );
            else if (result.node.getName()=="keyCSharp" ) playme ( mysound, 26.16 );
            else if (result.node.getName()=="keyDUpper" ) playme ( mysound, 53.88 );
            else if (result.node.getName()=="KeyDLower" ) playme ( mysound, 53.88 );
            else if (result.node.getName()=="keyDSharp" ) playme ( mysound, 83.25 );
            else if (result.node.getName()=="keyEUpper" ) playme ( mysound, 114.37 );
            else if (result.node.getName()=="KeyELower" ) playme ( mysound, 114.37 );
            else if (result.node.getName()=="keyFUpper" ) playme ( mysound, 147.33 );
            else if (result.node.getName()=="KeyFLower" ) playme (mysound, 147.33 );
            else if (result.node.getName()=="keyFSharp" ) playme ( mysound, 182.25 );
            else if (result.node.getName()=="keyGUpper" ) playme (mysound, 219.25 );
            else if (result.node.getName()=="KeyGLower" ) playme (mysound, 219.26 );
            else if (result.node.getName()=="keyGSharp" ) playme ( mysound, 258.46 );
            else if (result.node.getName()=="keyAUpper" ) playme ( mysound, 299.99 );
            else if (result.node.getName()=="KeyALower" ) playme ( mysound, 299.99 );
            else if (result.node.getName()=="keyASharp" ) playme ( mysound, 343.99 );
            else if (result.node.getName()=="keyBUpper" ) playme (mysound, 390.61 );
            else if (result.node.getName()=="KeyBLower" ) playme ( mysound, 390.61 );
            else if (result.node.getName()=="keycUpper2" ) playme ( mysound, 440.0 );
            else if (result.node.getName()=="KeyCLower2" ) playme ( mysound, 440.0 );
            else if (result.node.getName()=="piranax0" ) playme ( "Sounds/scream.wav", 666.0 );
        }
    }
};

// update function, do some work collecting touch/clicks and play the right thing
this.update = function(timeStep)
{
    if(Atomic.platform == "Android" || Atomic.platform == "iOS") // if we are on mobile
    {
        //iterate through each TouchState, if it doesn't touch any widgets, use it as a `mouse`
        for(var i = 0; i < Atomic.input.getNumTouches(); i++) // multitouch!
        {
            var touchState = Atomic.input.getTouch(i);
            if(touchState.touchedWidget === null)
            {
                var tpos = touchState.position;
 				pressme ( tpos[0], tpos[1] );
            }
        }
    }
    else // if its a desktop
    {
        var mousePos = Atomic.input.getMousePosition();
		pressme ( mousePos[0], mousePos[1] );

    	if ( Atomic.input.getKeyDown(Atomic.KEY_ESCAPE) ) Atomic.engine.exit();

		else if ( Atomic.input.getKeyPress(Atomic.KEY_Z ) )  playme ( mysound, 0 );  // and on desktop, play with the keyboard too. bonus
		else if ( Atomic.input.getKeyPress(Atomic.KEY_S ) )  playme ( mysound, 26.16 );
		else if ( Atomic.input.getKeyPress(Atomic.KEY_X ) )  playme ( mysound, 53.88 );
		else if ( Atomic.input.getKeyPress(Atomic.KEY_D ) )  playme ( mysound, 83.25 );
		else if ( Atomic.input.getKeyPress(Atomic.KEY_C ) )  playme ( mysound, 114.37 );
		else if ( Atomic.input.getKeyPress(Atomic.KEY_V ) )  playme ( mysound, 147.33 );
		else if ( Atomic.input.getKeyPress(Atomic.KEY_G ) )  playme ( mysound, 182.25 );
		else if ( Atomic.input.getKeyPress(Atomic.KEY_B ) )  playme ( mysound, 219.25 );
		else if ( Atomic.input.getKeyPress(Atomic.KEY_H ) )  playme ( mysound, 258.46 );
		else if ( Atomic.input.getKeyPress(Atomic.KEY_N ) )  playme ( mysound, 299.99 );
		else if ( Atomic.input.getKeyPress(Atomic.KEY_J ) )  playme ( mysound, 343.99 );
		else if ( Atomic.input.getKeyPress(Atomic.KEY_M ) )  playme ( mysound, 390.61 );
		else if ( Atomic.input.getKeyPress(Atomic.KEY_COMMA ) )  playme ( mysound, 440.0 );
    }

    if ( iFish !== null ) // make the pirana prowl around the screen
    {
		pfx -= (0.2310 * timeStep);
        iFish.position2D = [ pfx, Math.sin(pfx) ];
        if ( pfx < -3.2 ) pfx = 3.2;
    }

};


