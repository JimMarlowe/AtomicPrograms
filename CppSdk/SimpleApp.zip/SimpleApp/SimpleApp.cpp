//
// Copyright (c) 2008-2016 the Urho3D project.
// Copyright (c) 2014-2016, THUNDERBEAST GAMES LLC All rights reserved
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//

#include <Atomic/Engine/Application.h>
#include <Atomic/Core/CoreEvents.h>
#include <Atomic/Graphics/Camera.h>
#include <Atomic/Engine/Engine.h>
#include <Atomic/IO/FileSystem.h>
#include <Atomic/Graphics/Graphics.h>
#include <Atomic/Input/Input.h>
#include <Atomic/Input/InputEvents.h>
#include <Atomic/Graphics/Renderer.h>
#include <Atomic/Resource/ResourceCache.h>
#include <Atomic/Scene/Scene.h>
#include <Atomic/Scene/SceneEvents.h>
#include <Atomic/Graphics/Texture2D.h>
#include <Atomic/Graphics/Zone.h>
#include <Atomic/Graphics/Material.h>
#include <Atomic/Graphics/Model.h>
#include <Atomic/Graphics/Octree.h>
#include <Atomic/Graphics/Renderer.h>
#include <Atomic/Graphics/StaticModel.h>
#include <Atomic/Core/Timer.h>
#include <Atomic/UI/UI.h>
#include <Atomic/UI/UIView.h>
#include <Atomic/Resource/XMLFile.h>
#include <Atomic/IO/Log.h>

#include "SimpleApp.h"

ATOMIC_DEFINE_APPLICATION_MAIN(SimpleApp)

SimpleApp::SimpleApp(Context* context) :
    Application(context)
{
    // Register an object factory for our Rotator component, only needed if Rotator is used.
    context->RegisterFactory<Rotator>();
}


void SimpleApp::Setup()
{
    engineParameters_["WindowWidth"] = 1280; // Modify engine startup parameters
    engineParameters_["WindowHeight"] = 720;
    engineParameters_["FullScreen"]  = false;
    engineParameters_["Headless"]    = false;
    engineParameters_["Sound"]       = false;
    engineParameters_["LogName"]     = GetSubsystem<FileSystem>()->GetAppPreferencesDir("atomic", "logs") + GetTypeName() + ".log";
    engineParameters_["ResourcePaths"] = "Data;BaseResources;";
}

void SimpleApp::Start()
{
    SetWindowTitleAndIcon(); // Set custom window Title & Icon

    SubscribeToEvent(E_KEYDOWN, ATOMIC_HANDLER(SimpleApp, HandleKeyDown));  // to handle the keys

    DoSomething(); // your game code goes here
}

void SimpleApp::Stop()
{
    // possibly clean up allocated memory
}

void SimpleApp::HandleKeyDown(StringHash eventType, VariantMap& eventData)
{
    using namespace KeyDown;

    int key = eventData[P_KEY].GetInt();
    if(key == KEY_ESCAPE)
    {
        engine_->Exit();
    }
}

void SimpleApp::SetWindowTitleAndIcon()
{
    ResourceCache* cache = GetSubsystem<ResourceCache>();
    Graphics* graphics = GetSubsystem<Graphics>();
    graphics->SetWindowTitle("SimpleApp");
    Image* icon = cache->GetResource<Image>("Images/AtomicLogo32.png");
    graphics->SetWindowIcon(icon);
}

//
// This is the entry point for your 3d game
//
void SimpleApp::DoSomething()
{
    // Make a very simple, but compelling 3d scene
    ResourceCache* cache = GetSubsystem<ResourceCache>();
    scene_ = new Scene(context_);
    scene_->CreateComponent<Octree>();
    Node* lightNode = scene_->CreateChild("DirectionalLight");
    lightNode->SetDirection(Vector3(0.6f, -1.0f, 0.8f));
    Light* light = lightNode->CreateComponent<Light>();
    light->SetLightType(LIGHT_DIRECTIONAL);
    Node* planetNode = scene_->CreateChild("Planet");
    planetNode->SetScale(10.0f);
    planetNode->SetPosition(Vector3(0.0f, 0.0f, 0.0f));
    StaticModel* planetObject = planetNode->CreateComponent<StaticModel>();
    planetObject->SetModel(cache->GetResource<Model>("Models/Sphere.mdl"));
    planetObject->SetMaterial(cache->GetResource<Material>("Materials/planet.material"));
    Rotator* rotator = planetNode->CreateComponent<Rotator>();
    rotator->SetRotationSpeed(Vector3(0.0f, 20.0f, 1.0f));
    Node *cameraNode_ = scene_->CreateChild("Camera");
    cameraNode_->CreateComponent<Camera>();
    cameraNode_->SetPosition(Vector3(-4.7f, 3.6f, -16.2f));
    cameraNode_->SetRotation(Quaternion(11.4f, 15.8f, 0.0f));
    Renderer* renderer = GetSubsystem<Renderer>();
    SharedPtr<Viewport> viewport(new Viewport(context_, scene_, cameraNode_->GetComponent<Camera>()));
    renderer->SetViewport(0, viewport);
}


//
//  this class is for eye candy-ization only, it makes the world go round.
//
Rotator::Rotator(Context* context) :
    LogicComponent(context),
    rotationSpeed_(Vector3::ZERO)
{
    SetUpdateEventMask(USE_UPDATE);
}

void Rotator::SetRotationSpeed(const Vector3& speed)
{
    rotationSpeed_ = speed;
}

void Rotator::Update(float timeStep)
{
    node_->Rotate(Quaternion(rotationSpeed_.x_ * timeStep, rotationSpeed_.y_ * timeStep, rotationSpeed_.z_ * timeStep));
}




