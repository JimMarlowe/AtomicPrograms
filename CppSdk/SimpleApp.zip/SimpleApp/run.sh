#!/usr/bin/env bash
# script to run the cpp examples

./SimpleApp.bin -w -s -p "Data;BaseResources" -pp ".;"

