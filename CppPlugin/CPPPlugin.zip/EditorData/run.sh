./EXECUTABLE -w -s -p "Cache;Resources;BaseResources" -pp ".;..;"
