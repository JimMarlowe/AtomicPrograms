//
// Copyright (c) 2014-2017, THUNDERBEAST GAMES LLC All rights reserved
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//

#pragma once

#include <Atomic/Engine/Application.h>
#include <Atomic/Input/Input.h>

namespace Atomic
{
class Node;
class Scene;
}

using namespace Atomic;

class AtomicMain : public Application
{
    ATOMIC_OBJECT(AtomicMain, Application)

public:
    /// Constructor
    AtomicMain(Context* context);
    /// Setup before engine initialization. Modifies the engine parameters.
    virtual void Setup();
    /// Setup after engine initialization. Creates the logo, console & debug HUD.
    virtual void Start();
    /// Cleanup after the main loop. Called by Application.
    virtual void Stop();

protected:

private:

    void HandleUpdate(StringHash eventType, VariantMap& eventData);  // borrowed from HELLoGui3D
    bool Raycast(float maxDistance, Vector3& hitPos, Vector3 &hitNormal, Drawable*& hitDrawable);
    void ResetButton(); // settle down some
    void HandleKeyDown(StringHash eventType, VariantMap& eventData); // basic service to collect keys
    void SetWindowTitleAndIcon(); // basic service to fix up window
    void DoSomething();  // This is your game, any questions?
    WeakPtr<Scene> scene_;  // scene support for you game

};


#include <Atomic/Scene/LogicComponent.h>

/// Custom logic component for rotating a scene node. From Urho3D samples
class Rotator : public LogicComponent
{
    ATOMIC_OBJECT(Rotator, LogicComponent);
public:
    Rotator(Context* context); /// Construct.
    void SetRotationSpeed(const Vector3& speed); /// Set rotation speed about the Euler axes. Will be scaled with scene update time step.
    virtual void Update(float timeStep);  /// Handle scene update. Called by LogicComponent base class.
    const Vector3& GetRotationSpeed() const
    {
        return rotationSpeed_;    /// Return rotation speed.
    }
private:
    Vector3 rotationSpeed_;  /// Rotation speed.
};

