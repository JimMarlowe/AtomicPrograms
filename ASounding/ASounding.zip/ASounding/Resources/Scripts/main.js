// Copyright (c) 2017 JimMarlowe, Piranasoft
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//
// ASounding App
// JimMarlowe, Piranasoft

'use strict';

// load the scene, we'll hang stuff off this
Atomic.player.loadScene("Scenes/Scene.scene");

// make the host widget for the gui
var view = new Atomic.UIView();
var layout = new Atomic.UILayout();
layout.rect = view.rect;
layout.axis = Atomic.UI_AXIS_Y;
layout.layoutSize = Atomic.UI_LAYOUT_SIZE_AVAILABLE;
layout.layoutDistribution = Atomic.UI_LAYOUT_DISTRIBUTION_AVAILABLE;
layout.layoutPosition = Atomic.UI_LAYOUT_POSITION_GRAVITY;

//load the app skins for mobile and desktop
if (( Atomic.platform == "Android" && Atomic.graphics.width > 1200) || Atomic.platform == "iOS") {
    Atomic.ui.loadSkin("Sprites/mobile.tb.txt");
} else
    Atomic.ui.loadSkin("Sprites/desktop.tb.txt" );

// load the main layout
layout.load("Scenes/app_layout.tb.txt");

//Explicitly quitting an ios app is not allowed, why would you want to?
if(Atomic.platform == "iOS") {
    layout.getWidget("closeme").visibility = Atomic.UI_WIDGET_VISIBILITY_GONE;
}

view.addChild(layout);

// make the channels, channel 0 is the master, and behaves a little different.
var arr = [];
var channelDef = function()  {
    this.name = "";       // name of the channel, and id of the widget
    this.widget = null;   // ui widget
    this.sound = null;    // sound resource
    this.node = "";       // the scene node + player component
    this.volume = 0;      // current volume

    this.makeAll = function ( chname, soundfile, nodename, volume )  {
        this.makeChannel( chname, volume );
        this.makeSound( soundfile);
        this.makePlayer( nodename, volume );
    };
    this.makeChannel = function ( ch, vol ) {
        this.name = ch;
        this.widget = layout.getWidget(ch);
        this.widget.value = vol;
    };
    this.makeSound = function ( sf ) {
        if ( sf !== "" ) {
            this.sound = Atomic.cache.getResource("Sound", sf); // make sound resource
            this.sound.looped = true;
        }
    };
    this.makePlayer = function ( nn, vol ) {
        if ( this.name == "CHM" ) {  //special handling for master
            Atomic.audio.setMasterGain( "Master", vol );
        } else {
            this.node = Atomic.player.currentScene.createChild(nn); //make sound player
            var src = this.node.createComponent("SoundSource");
            src.gain = vol;
            src.soundType = Atomic.SOUND_EFFECT;
            src.play(this.sound);
        }
    };
    this.setVolume = function (vol) {
        this.volume = vol;
        this.widget.value = vol;
        if ( this.name == "CHM" ) {  //special handling for master
            Atomic.audio.setMasterGain( "Master", vol );
        } else {
            var src = this.node.getComponent("SoundSource");
            src.gain = this.volume;
        }
    };
};

// saves config files for desktop and mobile. in this case, just the fader settings 
var storedata = function( datafile, data ) {
    var filesystem = Atomic.getFileSystem(); // Get the FileSystem subsystem
    var documentsDir = "";
    if (Atomic.platform == "Android" || Atomic.platform == "iOS")
        documentsDir = filesystem.getUserDocumentsDir(); // somewhere writable on android
    else documentsDir = filesystem.getAppPreferencesDir("Piranasoft", "ASounding"); // desktop systems
    documentsDir += datafile; // add to our app dir, file for where our data will be
    var myfile = new Atomic.File(documentsDir, Atomic.FILE_WRITE);
    if (myfile.isOpen() ) {
        myfile.writeString( data );
        myfile.close();
    }
};

// loads config files for desktop and mobile. in this case, just the fader settings 
var restoredata = function( datafile ) {
    var filesystem = Atomic.getFileSystem(); // Get the FileSystem subsystem
    var documentsDir = "";
    if (Atomic.platform == "Android" || Atomic.platform == "iOS")
        documentsDir = filesystem.getUserDocumentsDir(); // somewhere writable on android
    else documentsDir = filesystem.getAppPreferencesDir("Piranasoft", "ASounding"); // desktop systems
    documentsDir += datafile; // add to our app dir, file for where our data will be
    var data = "";
    var myfile = new Atomic.File(documentsDir, Atomic.FILE_READ);
    if (myfile.isOpen() ) {
        data = myfile.readString();
        myfile.close();
    }
    if ( data !== "" ) { //extract csv data
        var vstrs = data.split(",");
        for (var i = 0; i < 9; i++)	{
            var vvol = parseFloat(vstrs[i]);
            arr[i].setVolume(vvol);
        }
    }
};

// populate the array with channel objects
for (var i = 0; i < 9; i++) arr.push((new channelDef()));
// initialize the channels, if I were smart, I could have done this different
arr[0].makeAll("CHM", "", "chmNode", 0.5);
arr[1].makeAll("CH1", "Sounds/white.ogg", "ch1Node", 0.0);
arr[2].makeAll("CH2", "Sounds/pinknoise.ogg", "ch2Node", 0.0);
arr[3].makeAll("CH3", "Sounds/generator_loop.ogg", "ch3Node", 0.0);
arr[4].makeAll("CH4", "Sounds/rain2.ogg", "ch4Node", 0.0);
arr[5].makeAll("CH5", "Sounds/beach-03.ogg", "ch5Node", 0.0);
arr[6].makeAll("CH6", "Sounds/forest-bright_01-loop.ogg", "ch6Node", 0.0);
arr[7].makeAll("CH7", "Sounds/cricketsounds090613.ogg", "ch7Node", 0.5);
arr[8].makeAll("CH8", "Sounds/night-01-loop.ogg", "ch8Node", 0.0);

// if there is a saved file, restore the settings
restoredata ( "faders.txt" );

// change channel volumes,  if I were smart, I could have done this different
arr[0].widget.onChanged = function() {
    arr[0].volume = arr[0].widget.value;
    Atomic.audio.setMasterGain( "Master", arr[0].volume ); //special handling for master
};
arr[1].widget.onChanged = function() {
    arr[1].volume = arr[1].widget.value;
    var src = arr[1].node.getComponent("SoundSource");
    src.gain = arr[1].volume;
};
arr[2].widget.onChanged = function() {
    arr[2].volume = arr[2].widget.value;
    var src = arr[2].node.getComponent("SoundSource");
    src.gain = arr[2].volume;
};
arr[3].widget.onChanged = function() {
    arr[3].volume = arr[3].widget.value;
    var src = arr[3].node.getComponent("SoundSource");
    src.gain = arr[3].volume;
};
arr[4].widget.onChanged = function() {
    arr[4].volume = arr[4].widget.value;
    var src = arr[4].node.getComponent("SoundSource");
    src.gain = arr[4].volume;
};
arr[5].widget.onChanged = function() {
    arr[5].volume = arr[5].widget.value;
    var src = arr[5].node.getComponent("SoundSource");
    src.gain = arr[5].volume;
};
arr[6].widget.onChanged = function() {
    arr[6].volume = arr[6].widget.value;
    var src = arr[6].node.getComponent("SoundSource");
    src.gain = arr[6].volume;
};
arr[7].widget.onChanged = function() {
    arr[7].volume = arr[7].widget.value;
    var src = arr[7].node.getComponent("SoundSource");
    src.gain = arr[7].volume;
};
arr[8].widget.onChanged = function() {
    arr[8].volume = arr[8].widget.value;
    var src = arr[8].node.getComponent("SoundSource");
    src.gain = arr[8].volume;
};

// exit the app the easy way, and saves the settings
layout.getWidget("closeme").onClick = function () {
    var faderstring = "";  // store csv, so we only need 1 string
    for (var i = 0; i < 9; i++)	{
        var vstr = arr[i].volume;
        faderstring += vstr + ",";
    }
    storedata( "faders.txt", faderstring );
    Atomic.engine.exit();
};

// bring up the credits box, in case you want to know more
layout.getWidget("about_window").onClick = function () {
    var window = new Atomic.UIWindow();
    window.setSettings ( Atomic.UI_WINDOW_SETTINGS_TITLEBAR + Atomic.UI_WINDOW_SETTINGS_RESIZABLE + Atomic.UI_WINDOW_SETTINGS_CLOSE_BUTTON );
    window.text = "ASounding";
    window.load("Scenes/app_info.tb.txt");
    var file = Atomic.cache.getFile("Scenes/app_credits.txt");
    var text = file.readText();
    window.getWidget("about_app").text = text;
    window.resizeToFitContent();
    view.addChild(window);
    window.center();
    window.getWidget("ok").onClick = function () {
        window.die();
        window = null;
    };
};
