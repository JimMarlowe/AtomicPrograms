/*
*   This started off life as Example 002 Quake3Map, and a number of other examples
* and tools. Changes we made as needed to get the job done. And that job is, to convert
* a Quake PK3 map into some other formats, those being obj, dae, irrmesh, stl, ply.
* This can be run on a command line, in fact, it must be, to specify the arguments
* to process ( see the usage statement ) Be warned, there are limitations.
* Not every Q3 PK3 can be converted, why? not sure.
*
*  Copyright (C) 2002-2012 Nikolaus Gebhardt
*
*  This software is provided 'as-is', without any express or implied
*  warranty.  In no event will the authors be held liable for any damages
*  arising from the use of this software.
*
*  Permission is granted to anyone to use this software for any purpose,
*  including commercial applications, and to alter it and redistribute it
*  freely, subject to the following restrictions:
*
*  1. The origin of this software must not be misrepresented; you must not
*     claim that you wrote the original software. If you use this software
*     in a product, an acknowledgment in the product documentation would be
*     appreciated but is not required.
*  2. Altered source versions must be plainly marked as such, and must not be
*     misrepresented as being the original software.
*  3. This notice may not be removed or altered from any source distribution.
*
*  Please note that the Irrlicht Engine is based in part on the work of the
*  Independent JPEG Group, the zlib and the libPng. This means that if you use
*  the Irrlicht Engine in your product, you must acknowledge somewhere in your
*  documentation that you've used the IJG code. It would also be nice to mention
*  that you use the Irrlicht Engine, the zlib and libPng. See the README files
*  in the jpeglib, the zlib and libPng for further informations.
* 
*  JimMarlowe, 2017, continuing the zlib license 
*/
#include <irrlicht.h>
#include <iostream>


using namespace irr;
using namespace scene;
using namespace gui;
using namespace video;
using namespace core;
using namespace quake3;
using namespace io;


#ifdef _MSC_VER
#pragma comment(lib, "Irrlicht.lib")
#endif

void usage(const char* name)
{
    std::cerr << "Usage: " << name << " [options] <srcpk3> <destfile>" << std::endl;
    std::cerr << "  where options are" << std::endl;
    std::cerr << " --close : this closes the tool when the conversion is complete" << std::endl;
    std::cerr << " --format=[obj|dae|irr|stl|ply]: Choose target output format, the default is obj" << std::endl;
    std::cerr << " --driver=[ogl|dx9|dx8|burn|sw]: override video driver, the default is platform specific" << std::endl;
}

// Marlowe quake map exporter
void export_map(IrrlichtDevice *device, scene::ISceneManager* smgr, EMESH_WRITER_TYPE mytype, scene::IMesh *mymesh, const io::path &myoutfile )
{
    // we need to capture the current directory and get the abs path for output file
    io::IFileSystem* fsx = device->getFileSystem();
    path absmyfile = fsx->getAbsolutePath (myoutfile);
    path wherearewe = fsx->getWorkingDirectory();
    path wheretogo = fsx->getFileDir(absmyfile);

    // we need to "cd" to the target directory, because files are created (.mtl) that dont follow the output file!
    if (fsx->changeWorkingDirectoryTo (wheretogo))
    {
        scene::IMeshWriter * objMeshWriter = smgr->createMeshWriter(mytype);
        io::IWriteFile * meshFile = device->getFileSystem()->createAndWriteFile(absmyfile);
        objMeshWriter->writeMesh(meshFile, mymesh);
        meshFile->drop();
        objMeshWriter->drop();
        std::cout <<  "MapConverter done with conversion for : " << myoutfile.c_str() << std::endl;
        fsx->changeWorkingDirectoryTo ( wherearewe );
    }
}

class MyEventReceiver : public IEventReceiver
{
public:
    // This is the one method that we have to implement
    virtual bool OnEvent(const SEvent& event)
    {
        // Remember whether each key is down or up
        if (event.EventType == irr::EET_KEY_INPUT_EVENT)
            KeyIsDown[event.KeyInput.Key] = event.KeyInput.PressedDown;
        return false;
    }

    // This is used to check whether a key is being held down
    virtual bool IsKeyDown(EKEY_CODE keyCode) const
    {
        return KeyIsDown[keyCode];
    }

    MyEventReceiver()
    {
        for (u32 i=0; i<KEY_KEY_CODES_COUNT; ++i)
            KeyIsDown[i] = false;
    }

private:
    // We use this array to store the current state of each key
    bool KeyIsDown[KEY_KEY_CODES_COUNT];
};


int main(int argc, char* argv[])
{

    if ((argc < 3) || ((argc==3) && (argv[1][0]=='-')))
    {
        usage(argv[0]);
        return 1;
    }

    core::stringc mypk3;  //the map to convert
    core::stringc mybsp;    //the bsp that is in the loaded pk3
    core::stringc myoutput;  // the file that will be written
    scene::EMESH_WRITER_TYPE output_type = EMWT_OBJ; // OBJ is the default type
    bool convertclose=false; // close at the end of convert
    char overridedrv = 'f';  // the override software driver

    u32 ia=1;
    while (argv[ia][0]=='-')
    {
        core::stringc format = argv[ia];
        if (format.size() > 3)
        {
            if (format.equalsn("--format=",9))
            {
                format = format.subString(9,format.size());
                if (format=="dae")
                    output_type = EMWT_COLLADA;
                else if (format=="stl")
                    output_type = EMWT_STL;
                else if (format=="obj")
                    output_type = EMWT_OBJ;
                else if (format=="ply")
                    output_type = EMWT_PLY;
                else if (format=="irr")
                    output_type = EMWT_IRR_MESH;
                else
                    output_type = EMWT_OBJ;
            }
            else if (format.equalsn("--driver=",9))
            {
                format = format.subString(9,format.size());
                if (format=="ogl")
                    overridedrv = 'a';
                else if (format=="dx9")
                    overridedrv = 'b';
                else if (format=="dx8")
                    overridedrv = 'c';
                else if (format=="burn")
                    overridedrv = 'd';
                else if (format=="sw")
                    overridedrv = 'e';
            }
            else if (format =="--close")
                convertclose=true;
        }
        else if (format=="--")
        {
            ++ia;
            break;
        }
        ++ia;
    }

    // get the src and dest file indexes on the command line
    const s32 srcpk3 = ia;
    const s32 destmap = ia+1;

    --argc;
    if ((argc<srcpk3) || (argc<destmap))
    {
        std::cerr << "Not enough files given." << std::endl;
        usage(argv[0]);
        return 1;
    }

    // and capture the files
    mypk3 = argv[srcpk3];
    myoutput = argv[destmap];

    // select driver type - by default, we'll guess by compiled platform
    video::E_DRIVER_TYPE driverType;
    char drvtype = 'd';  // no platform driver guess = burnings

#if defined (_IRR_WINDOWS_)
    drvtype = 'b';  // EDT_DIRECT3D9;
#elif defined(_IRR_OSX_PLATFORM_)
    drvtype = 'a'; // EDT_OPENGL;
#elif defined(_IRR_LINUX_PLATFORM_)
    drvtype = 'a'; // EDT_OPENGL;
#endif

    if ( overridedrv != 'f' ) // the user knows better
        drvtype = overridedrv;

    switch(drvtype)
    {
    case 'a':
        driverType = video::EDT_OPENGL;
        break;
    case 'b':
        driverType = video::EDT_DIRECT3D9;
        break;
    case 'c':
        driverType = video::EDT_DIRECT3D8;
        break;
    case 'd':
        driverType = video::EDT_BURNINGSVIDEO;
        break;
    case 'e':
        driverType = video::EDT_SOFTWARE;
        break;
    case 'f':
        driverType = video::EDT_NULL;
        break;
    default:
        return 1;
    }

    // create device and exit if creation failed
    MyEventReceiver receiver;
    IrrlichtDevice *device = createDevice(driverType, core::dimension2d<u32>(640, 480), 16, false, false, false, &receiver);
    if (device == 0)
        return 1; // could not create selected driver.

    video::IVideoDriver* driver = device->getVideoDriver();
    scene::ISceneManager* smgr = device->getSceneManager();

    std::cout <<  "MapConverter pk3 file : " << mypk3.c_str() << std::endl;
    device->getFileSystem()->addFileArchive( mypk3.c_str(), false);  // the false make it case sensitive for linux

    irr::core::string<char>s;
    io::IFileSystem* fsx = device->getFileSystem();
    for (unsigned int i = 0; i != fsx->getFileArchiveCount(); ++i )
    {
        IFileArchive * archive = fsx->getFileArchive ( i );
        const IFileList *archList = archive->getFileList();
        for (unsigned int ii=0; ii< archList->getFileCount(); ++ii)
        {
            s = archList->getFullFileName(ii);
            if ( s.find (".bsp") >= 0 ) //  finds another string in this string
                mybsp = s;  // we'll take the last one, good or bad...
        }
    }

    // find the loaded pk3 bsps by searching the archive
    std::cout <<  "MapConverter bsp : " << mybsp.c_str() << std::endl;

    IQ3LevelMesh* mesh = (IQ3LevelMesh*) smgr->getMesh ( mybsp.c_str() );

    // this is failing at times on maps that do not follow some unwritten standards
    // and end up not creating node or geometry in the octree.
    s32 minimalNodes = 2048;
    if (mesh)
        smgr->addOctreeSceneNode(mesh->getMesh(0), 0, -1, minimalNodes );

    // debug message, only useful to confirm a failing map
    IMesh *geometry = mesh->getMesh(E_Q3_MESH_GEOMETRY);
    if ( geometry )
    {
        std::cout <<  "MapConverter found " << geometry->getMeshBufferCount() << " Mesh Buffers" << std::endl;
    }

    vector3df PlayerPosition;
    tQ3EntityList &entityList = mesh->getEntityList ();
    u32 pos;
    vector3df tempOrigin;
    bool wasStart = false;
    for ( u32 e = 0; e != entityList.size (); ++e )
    {
        for ( u32 g = 0; g != entityList[e].getGroupSize (); ++g )
        {
            wasStart = false;
            const SVarGroup *group = entityList[e].getGroup ( g );
            for ( u32 index = 0; index < group->Variable.size (); ++index )
            {
                const SVariable &v = group->Variable[index];
                pos = 0;
                if ( v.name == "origin" )
                {
                    tempOrigin = getAsVector3df ( v.content, pos );
                }
                if ( v.name == "classname" && v.content.find ("_player_") >= 0 )  // find a player start of some type
                    wasStart = true;
            }
            if ( wasStart )
            {
                PlayerPosition = tempOrigin;
                std::cout <<  "MapConverter decoded a player start at : " << tempOrigin.X << ", "  << tempOrigin.Y << ", "<< tempOrigin.Z << std::endl;
            }
        }
    }

    // add fps cam to drive around in the map
    smgr->addCameraSceneNodeFPS();

    ICameraSceneNode * camera = device->getSceneManager()->getActiveCamera ();
    if ( camera )
    {
        camera->setPosition( PlayerPosition ); // put the can at a start point
        std::cout <<  "MapConverter set camera at : " <<  PlayerPosition.X << ", " << PlayerPosition.Y << ", " << PlayerPosition.Z << std::endl;
    }

    device->getCursorControl()->setVisible(false);

    int lastFPS = -1;
    int exportedit = 0;

    while(device->run())
    {
        if (device->isWindowActive())
        {

            if(receiver.IsKeyDown(KEY_ESCAPE) || receiver.IsKeyDown(KEY_KEY_Q))
            {
                device->drop();
                return 0;
            }

            driver->beginScene(true, true, video::SColor(255,200,200,200));
            smgr->drawAll();
            device->getGUIEnvironment()->drawAll();
            driver->endScene();

            int fps = driver->getFPS();

            if (lastFPS != fps)
            {
                core::stringw str = L"Irrlicht Engine - MapConverter [";
                str += driver->getName();
                str += "] FPS:";
                str += fps;

                device->setWindowCaption(str.c_str());
                lastFPS = fps;

                if ( exportedit == 0 )
                {
                    export_map(device, smgr, output_type, (scene::IMesh *)mesh->getMesh(0), myoutput );
                    exportedit = 1;
                    if ( convertclose )
                    {
                        device->drop();
                        return 0;
                    }
                    std::cout <<  "MapConverter conversion completed, use Alt+F4, ESC or Q to exit." << std::endl;
                }
            }
        }
        else
            device->yield();
    }

    device->drop();
    return 0;
}

