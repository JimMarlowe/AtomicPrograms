// Copyright (c) 2017 Piranasoft
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
// Talk Like a Pirate app
// JimMarlowe, Piranasoft ( aka PiAAAAAARRRRanasoft )

'use strict';

var mycounter = 0;
var pirategain = .5;

Atomic.player.loadScene("Scenes/Scene.scene");
var view = new Atomic.UIView();
var layout = new Atomic.UILayout();
layout.rect = view.rect;
layout.axis = Atomic.UI_AXIS_Y;
layout.layoutSize = Atomic.UI_LAYOUT_SIZE_AVAILABLE;
layout.layoutDistribution = Atomic.UI_LAYOUT_DISTRIBUTION_AVAILABLE;
layout.layoutPosition = Atomic.UI_LAYOUT_POSITION_GRAVITY;
layout.spacing = 1;

if (Atomic.platform == "Android" || Atomic.platform == "iOS")
{
    // 'tis a hires phone, perhaps
    Atomic.ui.loadSkin("Sprites/piratemobile.tb.txt");

    //Explicitly quitting a yellow bellied app is not allowed in a one-eyed bow-legged iOS, so be asayin Pirate Josh
    if(Atomic.platform == "iOS")
    {
        window.getWidget("closeme").visibility = Atomic.UI_WIDGET_VISIBILITY_GONE;
    }
}
else
    Atomic.ui.loadSkin("Sprites/pirateskin.tb.txt");

layout.load("Scripts/tlfp_layout.tb.txt");
view.addChild(layout);

var playme = function(soundFile)
{
    var sfx = Atomic.cache.getResource("Sound", soundFile);
    sfx.looped = false;
    var sfxNode = Atomic.player.currentScene.createChild("SFXNode");
    var sfxSource = sfxNode.createComponent("SoundSource");
    sfxSource.gain = pirategain;
    sfxSource.soundType = Atomic.SOUND_EFFECT;
    sfxSource.play(sfx);
};

Date.prototype.isLeapYear = function()
{
    var year = this.getFullYear();
    if((year & 3) != 0) return false;
    return ((year % 100) != 0 || (year % 400) == 0);
};

Date.prototype.getDOY = function() // Get Day of Year
{
    var dayCount = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    var mn = this.getMonth();
    var dn = this.getDate();
    var dayOfYear = dayCount[mn] + dn;
    if(mn > 1 && this.isLeapYear()) dayOfYear++;
    return dayOfYear;
};

var td = new Date();
var d1 = new Date(td.getFullYear(), td.getMonth() + 1, td.getDate());
var d2 = new Date(2016, 9, 19);
var today = d1.getDOY();
var tlpd = d2.getDOY();
var piText = "";
var daysleft = tlpd - today;

if (daysleft == 0 )
    piText = "This IS International Talk Like a Pirate Day! Prepare to be boarded, Yarrr                                          ";
else if ( daysleft < 0 )
{
    var ayr = 365 - tlpd;
    d2 = new Date(td.getFullYear() + 1, 9, 19);
    tlpd = d2.getDOY();
    ayr = ayr + tlpd;
    piText = "Avast thar be " + ayr.toString() + " days until the next International Talk Like a Pirate Day, Cap`n                ";
}
else
{
    piText =  daysleft.toString() + " days until International Talk Like a Pirate Day, Arrrrr                                     ";
}

playme("Sounds/introarrr.ogg"); // get ye party started

layout.getWidget("t00").onClick = function () { playme("Sounds/allhandsdeck.ogg"); };
layout.getWidget("t01").onClick = function () { playme("Sounds/walkplank.ogg"); };
layout.getWidget("t02").onClick = function () { playme("Sounds/ayeayecaptn.ogg"); };
layout.getWidget("t03").onClick = function () { playme("Sounds/prepareboarded.ogg"); };
layout.getWidget("t04").onClick = function () { playme("Sounds/battenhatches.ogg"); };
layout.getWidget("t10").onClick = function () { playme("Sounds/cutropes.ogg"); };
layout.getWidget("t11").onClick = function () { playme("Sounds/surrendertresure.ogg"); };
layout.getWidget("t12").onClick = function () { playme("Sounds/swabthedeck.ogg"); };
layout.getWidget("t13").onClick = function () { playme("Sounds/arrrr.ogg"); };
layout.getWidget("t14").onClick = function () { playme("Sounds/bootymine.ogg"); };
layout.getWidget("t20").onClick = function () { playme("Sounds/cantreadnorwrite.ogg"); };
layout.getWidget("t21").onClick = function () { playme("Sounds/deadmentales.ogg"); };
layout.getWidget("t22").onClick = function () { playme("Sounds/ropesend.ogg"); };
layout.getWidget("t23").onClick = function () { playme("Sounds/itdrivesmenuts.ogg"); };
layout.getWidget("t24").onClick = function () { playme("Sounds/heatriesbunghole.ogg"); };
layout.getWidget("t30").onClick = function () { playme("Sounds/shivermetimbers.ogg"); };
layout.getWidget("t31").onClick = function () { playme("Sounds/stormabrewin.ogg"); };
layout.getWidget("t32").onClick = function () { playme("Sounds/ahoymatey.ogg"); };
layout.getWidget("t33").onClick = function () { playme("Sounds/yohoyoho.ogg"); };
layout.getWidget("t34").onClick = function () { playme("Sounds/raisesails.ogg"); };
layout.getWidget("t40").onClick = function () { playme("Sounds/rammingspeed.ogg"); };
layout.getWidget("t41").onClick = function () { playme("Sounds/hailsea.ogg"); };
layout.getWidget("t42").onClick = function () { playme("Sounds/scuppertongue.ogg"); };
layout.getWidget("t43").onClick = function () { playme("Sounds/standback.ogg"); };
layout.getWidget("t44").onClick = function () { playme("Sounds/belaytalk.ogg"); };
layout.getWidget("tvup").onClick = function ()
{
    if ( pirategain < 1.0 )
    {
        pirategain += .1;
        playme("Sounds/volarr.ogg");
    }
};

layout.getWidget("tvdn").onClick = function ()
{
    if ( pirategain > .2 )
    {
        pirategain -= .1;
        playme("Sounds/volarr.ogg");
    }
};

layout.getWidget("closeme").onClick = function ()
{
    Atomic.engine.exit();
}; 

layout.getWidget("tlfp").onClick = function ()
{
    var window = new Atomic.UIWindow();
    window.setSettings ( Atomic.UI_WINDOW_SETTINGS_TITLEBAR
                         + Atomic.UI_WINDOW_SETTINGS_RESIZABLE
                         + Atomic.UI_WINDOW_SETTINGS_CLOSE_BUTTON );
    window.text = "Talk Like a Pirate";
    window.load("Scripts/tlfp_info.tb.txt");
    var file = Atomic.cache.getFile("Scripts/credits.txt");
    var text = file.readText();
    window.getWidget("about_tlfp").text = text;
    window.resizeToFitContent();
    view.addChild(window);
    window.center();
    window.getWidget("ok").onClick = function ()
    {
        window.die();
        window = null;
    };
};

this.update = function(timeStep)
{
    mycounter += 1;
    if( mycounter > 28 ) // tickertape message to swab the deck with
    {
        var len = piText.length;
        var first = piText.charAt(0);
        piText = piText.substring(1, len) + first;
        layout.getWidget("piinfo").setText(piText);
        mycounter = 0;
    }
}
