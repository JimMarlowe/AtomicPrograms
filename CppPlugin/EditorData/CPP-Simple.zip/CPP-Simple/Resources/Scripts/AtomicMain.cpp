//
// Copyright (c) 2014-2016, THUNDERBEAST GAMES LLC All rights reserved
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//

#include <Atomic/Engine/Application.h>
#include <Atomic/Core/CoreEvents.h>
#include <Atomic/Graphics/Camera.h>
#include <Atomic/Engine/Engine.h>
#include <Atomic/IO/FileSystem.h>
#include <Atomic/Graphics/Graphics.h>
#include <Atomic/Input/Input.h>
#include <Atomic/Input/InputEvents.h>
#include <Atomic/Graphics/Renderer.h>
#include <Atomic/Resource/ResourceCache.h>
#include <Atomic/Scene/Scene.h>
#include <Atomic/Scene/SceneEvents.h>
#include <Atomic/Graphics/Texture2D.h>
#include <Atomic/Graphics/Zone.h>
#include <Atomic/Graphics/Material.h>
#include <Atomic/Graphics/Model.h>
#include <Atomic/Graphics/Octree.h>
#include <Atomic/Graphics/Renderer.h>
#include <Atomic/Graphics/StaticModel.h>
#include <Atomic/Graphics/Technique.h>
#include <Atomic/Graphics/ParticleEffect.h>
#include <Atomic/Graphics/ParticleEmitter.h>
#include <Atomic/Core/Timer.h>
#include <Atomic/UI/UI.h>
#include <Atomic/UI/UIView.h>
#include <Atomic/Resource/XMLFile.h>
#include <Atomic/IO/Log.h>
#include <Atomic/Graphics/DecalSet.h>

#include "AtomicMain.h"

ATOMIC_DEFINE_APPLICATION_MAIN(AtomicMain)

AtomicMain::AtomicMain(Context* context) :
    Application(context)
{
    // Register an object factory for our Rotator component, only needed if Rotator is used.
    context->RegisterFactory<Rotator>();
}


void AtomicMain::Setup()
{
    engineParameters_["WindowWidth"] = 1280; // Modify engine startup parameters
    engineParameters_["WindowHeight"] = 720;
    engineParameters_["FullScreen"]  = false;
    engineParameters_["Headless"]    = false;
    engineParameters_["Sound"]       = false;
    engineParameters_["LogName"]     = GetSubsystem<FileSystem>()->GetAppPreferencesDir("atomic", "logs") + GetTypeName() + ".log";
    engineParameters_["ResourcePaths"] = "Cache;Resources;BaseResources;";
}

void AtomicMain::Start()
{
    SetWindowTitleAndIcon(); // Set custom window Title & Icon

    SubscribeToEvent(E_KEYDOWN, ATOMIC_HANDLER(AtomicMain, HandleKeyDown));  // to handle the keys

    DoSomething(); // your game code goes here
}

void AtomicMain::Stop()
{
    // possibly clean up allocated memory
}

void AtomicMain::HandleKeyDown(StringHash eventType, VariantMap& eventData)
{
    using namespace KeyDown;

    int key = eventData[P_KEY].GetInt();
    if(key == KEY_ESCAPE)
    {
        engine_->Exit();
    }
    if(key == KEY_R)
    {
        ResetButton();
    }

}

void AtomicMain::SetWindowTitleAndIcon()
{
    ResourceCache* cache = GetSubsystem<ResourceCache>();
    Graphics* graphics = GetSubsystem<Graphics>();
    graphics->SetWindowTitle("CPP-Simple");
    Image* icon = cache->GetResource<Image>("Images/AtomicLogo32.png");
    graphics->SetWindowIcon(icon);
}

//
// This is the entry point for your 3d game
//
void AtomicMain::DoSomething()
{
    // Make a very simple, but compelling 3d scene
    ResourceCache* cache = GetSubsystem<ResourceCache>();
    scene_ = new Scene(context_);
    scene_->CreateComponent<Octree>();
    Node* lightNode = scene_->CreateChild("DirectionalLight");
    lightNode->SetDirection(Vector3(0.6f, -1.0f, 0.8f));
    Light* light = lightNode->CreateComponent<Light>();
    light->SetLightType(LIGHT_DIRECTIONAL);
    Node* planetNode = scene_->CreateChild("Planet");
    planetNode->SetScale(10.0f);
    planetNode->SetPosition(Vector3(0.0f, 0.0f, 0.0f));
    StaticModel* planetObject = planetNode->CreateComponent<StaticModel>();
    planetObject->SetModel(cache->GetResource<Model>("Models/Sphere.mdl"));
    planetObject->SetMaterial(cache->GetResource<Material>("Materials/planet.material"));
    Rotator* rotator = planetNode->CreateComponent<Rotator>();
    rotator->SetRotationSpeed(Vector3(0.0f, 20.0f, 1.0f));
    Node *cameraNode_ = scene_->CreateChild("Camera");
    cameraNode_->CreateComponent<Camera>();
    cameraNode_->SetPosition(Vector3(-4.7f, 3.6f, -16.2f));
    cameraNode_->SetRotation(Quaternion(11.4f, 15.8f, 0.0f));
    Renderer* renderer = GetSubsystem<Renderer>();
    SharedPtr<Viewport> viewport(new Viewport(context_, scene_, cameraNode_->GetComponent<Camera>()));
    renderer->SetViewport(0, viewport);

    // and can I get an update?
    SubscribeToEvent(E_UPDATE, ATOMIC_HANDLER(AtomicMain, HandleUpdate));
}

void AtomicMain::ResetButton()
{
    Node* planetNode = scene_->GetChild("Planet", true);
    if (planetNode)
    {
        planetNode->RemoveAllChildren();
        planetNode->RemoveComponent("DecalSet");
    }
}

bool AtomicMain::Raycast(float maxDistance, Vector3& hitPos, Vector3& hitNormal, Drawable*& hitDrawable)
{
    hitDrawable = 0;

    Input* input = GetSubsystem<Input>();

    IntVector2 pos = input->GetMousePosition();

    // Check the cursor is visible and there is no UI element in front of the cursor
    if (!input->IsMouseVisible())
        return false;

    Graphics* graphics = GetSubsystem<Graphics>();
    Node *cameraNode_ = scene_->GetChild("Camera", true);
    Camera* camera = cameraNode_->GetComponent<Camera>();
    Ray cameraRay = camera->GetScreenRay((float)pos.x_ / graphics->GetWidth(), (float)pos.y_ / graphics->GetHeight());
    // Pick only geometry objects, not eg. zones or lights, only get the first (closest) hit
    PODVector<RayQueryResult> results;
    RayOctreeQuery query(results, cameraRay, RAY_TRIANGLE, maxDistance, DRAWABLE_GEOMETRY);
    scene_->GetComponent<Octree>()->Raycast(query);

    for (unsigned i = 0; i < results.Size(); i++)
    {
        RayQueryResult& result = results[i];
        hitPos = result.position_;
        hitNormal = result.normal_;
        hitDrawable = result.drawable_;

        return true;
    }

    return false;
}

void AtomicMain::HandleUpdate(StringHash eventType, VariantMap& eventData)
{
    using namespace Update;

    Vector3 hitPos;
    Vector3 hitNormal;
    Drawable* hitDrawable;
    bool result = Raycast(250.0f, hitPos, hitNormal, hitDrawable);

    Input* input = GetSubsystem<Input>();

    if (result && input->GetMouseButtonPress(MOUSEB_LEFT) )  // destroy the world with a mouse click
    {
        ResourceCache* cache = GetSubsystem<ResourceCache>();
        Node *cameraNode_ = scene_->GetChild("Camera", true);
        Node* planetNode = scene_->GetChild("Planet", true);
        Node* node = planetNode->CreateChild("GreatBallOfFire");
        node->SetScale(0.3f);
        node->SetWorldPosition(hitPos + (hitNormal * .15f));
        node->SetWorldDirection(hitNormal);
        node->Pitch(90);
        ParticleEmitter* emitter = node->CreateComponent<ParticleEmitter>();
        emitter->SetEffect(cache->GetResource<ParticleEffect>("Particle/UIFire.xml"));

        DecalSet* decal = planetNode->GetComponent<DecalSet>();
        if (!decal)
        {
            decal = planetNode->CreateComponent<DecalSet>();
            decal->SetMaterial(cache->GetResource<Material>("Materials/BoomDecal.xml"));
        }
        decal->AddDecal(hitDrawable, hitPos, cameraNode_->GetRotation(), 1.34f, 1.0f, 1.0f, Vector2::ZERO, Vector2::ONE);
    }
}


Rotator::Rotator(Context* context) :
    LogicComponent(context),
    rotationSpeed_(Vector3::ZERO)
{
    SetUpdateEventMask(USE_UPDATE);
}

void Rotator::SetRotationSpeed(const Vector3& speed)
{
    rotationSpeed_ = speed;
}

void Rotator::Update(float timeStep)
{
    node_->Rotate(Quaternion(rotationSpeed_.x_ * timeStep, rotationSpeed_.y_ * timeStep, rotationSpeed_.z_ * timeStep));
}




