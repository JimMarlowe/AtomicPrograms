#pragma once

#include <Atomic/Engine/Application.h>

namespace Atomic
{
class Node;
class Scene;
class UIView;
}

using namespace Atomic;

#include <Atomic/Scene/LogicComponent.h>

/// Custom logic component for rotating a scene node. From Urho3D samples
class Roller : public LogicComponent
{
    ATOMIC_OBJECT(Roller, LogicComponent);

public:
    Roller(Context* context); /// Construct.
    void SetRotationSpeed(const float speedxyz); /// Set rotation speed. Will be scaled with scene update time step.
    virtual void Update(float timeStep);  /// Handle scene update. Called by LogicComponent base class.
    const float GetRotationSpeed() const
    {
        return rotationSpeed_;    /// Return rotation speed.
    }
private:
    float rotationSpeed_;  /// Rotation speed.
};

