Broken Glass Font

The Broken Glass font is a display font reminiscent of broken glass. It is based on a block-letter font. It comes with letters, numbers, punctuation and international characters. This font is in the public domain. Please read the terms of use at http://jlhfonts.blogspot.com/.