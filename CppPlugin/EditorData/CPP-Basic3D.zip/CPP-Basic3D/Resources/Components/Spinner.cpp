#include <Atomic/Scene/Node.h>
#include "Spinner.h"

Rotator::Rotator(Context* context) :
    LogicComponent(context),
    rotationSpeed_(Vector3::ZERO)
{
    SetUpdateEventMask(USE_UPDATE);
}

void Rotator::SetRotationSpeed(const Vector3& speedxyz)
{
    rotationSpeed_ = speedxyz;
}

void Rotator::Update(float timeStep)
{
    node_->Rotate(Quaternion(rotationSpeed_.x_ * timeStep, rotationSpeed_.y_ * timeStep, rotationSpeed_.z_ * timeStep));
}

